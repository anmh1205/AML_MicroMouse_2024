void mazeSolve()
{
    switch (nextMove)
    {
    case 'F' :
        //move forward
        break;
    
    case 'R' :
        //move right
        break;

    case 'L' :
        //move left
        break;
    
    case 'B' :
        //move back
        break;
    }
}