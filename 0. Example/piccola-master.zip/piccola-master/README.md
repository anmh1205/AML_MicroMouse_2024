# piccola
This repository contains all the codes used in building the micromouse named "Piccola", to participate in the Robofest 2019 competion in Sri lanka.
You can find codes for following functionalities as header files inside the 'code' folder
- interfaceing multiple VL6180X with stm32
- forward, turns, brake, acceleration functions
- debuging using HC06 bluetooth module
- flood fill  algorithm and shortest path calculating
- reading writing with eeprom stm32
- piccola maze solving stratergy

Stay tuned for a article series on medium about piccola!
