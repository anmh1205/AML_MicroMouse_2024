ST VL53L0X ToF laser distance sensor. I used ST API to run this sensor. It's polling version using Single Measeurement method.

STM43F401CC (https://sklep.msalamon.pl/produkt/stm32f401ccu6-dev-board/)
STM32CubeIDE 1.1.0
HAL F4 1.24.2

Description: https://msalamon.pl/tani-laserowy-pomiar-odleglosci-z-czujnikiem-tof-vl53l0x/
GitHub:  https://github.com/lamik/VL53L0X_API_STM32_HAL
Contact: mateusz@msalamon.pl