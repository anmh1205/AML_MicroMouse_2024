# Maze solving part

![maze classes diagram](class_design/maze_classes.jpg)
